package com.sathyatel.zuul;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GatewayZuulApplicationTests {

	@Test
	public void contextLoads() {
	}

}
