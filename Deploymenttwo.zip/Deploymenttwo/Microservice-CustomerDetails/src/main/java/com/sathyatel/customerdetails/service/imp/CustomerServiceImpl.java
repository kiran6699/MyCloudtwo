package com.sathyatel.customerdetails.service.imp;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.customerdetails.entity.Customer;
import com.sathyatel.customerdetails.model.CustomerDTO;
import com.sathyatel.customerdetails.model.Login;
import com.sathyatel.customerdetails.repository.CustomerRepository;
import com.sathyatel.customerdetails.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService {
		@Autowired
	CustomerRepository repository;
	

	@Override
	public String registerCustomer(Customer customer) {
		boolean flag = repository.existsById(customer.getPhoneNo());
		if (flag == true) {

			return "Sorry!  given PhoneNo already exists!!!";
		} else {
			repository.save(customer);
			return "customer added  successfully!!!";
		}
	}

	@Override
	public boolean loginCustomer(Login login) {
		Integer count = repository.verifyUserLogin(login.getPhoneNo(), login.getPassword());
		if (count == 1) {
			
			return true;
		} else {
			return false;
		}
     }

	@Override
	public CustomerDTO getProfile(Long phoneNo) {
		Optional<Customer> opt = repository.findById(phoneNo);
		Customer customer = opt.get();
		CustomerDTO customerdto = new CustomerDTO();
		BeanUtils.copyProperties(customer, customerdto);

		return customerdto;
	}
}
