package com.sathyatel.customerdetails.model;

import java.util.List;

public class CustomerDTO {

	private Long phoneNo;
	private String name;
	private String password;
	private String planId;
	private  PlanDTO plaDto;
	private List<Long> friendsContactNumbers;
	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public PlanDTO getPlaDto() {
		return plaDto;
	}

	public void setPlaDto(PlanDTO plaDto) {
		this.plaDto = plaDto;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public List<Long> getFriendsContactNumbers() {
		return friendsContactNumbers;
	}

	public void setFriendsContactNumbers(List<Long> friendsContactNumbers) {
		this.friendsContactNumbers = friendsContactNumbers;
	}

	

}
