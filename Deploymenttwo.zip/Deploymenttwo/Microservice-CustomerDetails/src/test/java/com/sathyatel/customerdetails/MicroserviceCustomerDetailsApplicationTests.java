package com.sathyatel.customerdetails;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MicroserviceCustomerDetailsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
